import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.CookieHandler;
import java.net.CookieManager;
import java.net.CookiePolicy;
import java.net.HttpURLConnection;
import java.net.SocketException;
import java.net.URL;
import java.util.Scanner;
import java.util.Vector;



public class robotParser {
	
	public void robot(URL URL, Vector<String> disallowedURLS) throws IOException
	{
		
		String host = URL.getHost();
		String protocol = URL.getProtocol();
		// form URL of the robots.txt file
	    String robotUrl = protocol + "://" + host + "/robots.txt";
	    
	    URL robotUrlObj = new URL(robotUrl);
	    
	    //To solve Protocol exception server redirected too many times
	    CookieHandler.setDefault(new CookieManager(null, CookiePolicy.ACCEPT_ALL));
	    
	    HttpURLConnection connection = (HttpURLConnection)  robotUrlObj.openConnection();
		try{
			connection.connect();
		}catch(IOException e)
		{
			return;
		}
		
		//validation of the content type of the robots.txt 
		String contentType = connection.getContentType();
		
		int indexOf = 0;
		
	   if(contentType == null || contentType.contains("text/plain"))
	    {
	    	Scanner scan = null;
	    	try{
	    		scan = new Scanner(robotUrlObj.openStream());						//open the stream to read the robots.txt
	    	}
	    	catch (FileNotFoundException|SocketException e)
	    	{
	    		return;
	    	}
	    	catch (IOException e)
	    	{
	    		return;
	    	}
	    	
	    	
	    	if(scan.hasNextLine()) 													//to check if isEmpty
	    	{
	    		String lineString = null;
	    		do{
	    			lineString = scan.nextLine();									//go to the next line until the scanner find "user-agent: *"
	    		}while(!lineString.toLowerCase().contains("user-agent: *") && scan.hasNextLine());
	    	
	    		if(scan.hasNextLine())
	    			lineString = scan.nextLine();									//step to the next line to get the disallowed links
	    		while((scan.hasNextLine() && !lineString.toLowerCase().contains("user-agent:")) || lineString.contains("Disallow:"))  //Check if the robots.txt has finished or more disallow
	    		{
	    			indexOf = lineString.indexOf(":");
	    			if(lineString.contains("Disallow"))
	    			{
	    				if(lineString.length() != 9)								//if there is something written in the disallow
	    					disallowedURLS.add(lineString.substring(indexOf+2));	//save the disallow link in the vector    					
	    			}
	    		
	    			if(scan.hasNextLine())
	    				lineString = scan.nextLine();								//go to the next line to see the next disallowed link
	    			else lineString = "";
	    		}
	    	} 
	    	scan.close();															//close the scanner
	    }
	}
}