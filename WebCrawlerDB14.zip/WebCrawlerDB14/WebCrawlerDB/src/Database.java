import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.LinkedList;

import org.jsoup.nodes.Document;
	
public class Database {

	public Connection conn = null;
	 
		public Database() {
			try {
				Class.forName("com.mysql.jdbc.Driver");
				String url = "jdbc:mysql://localhost:3306/searchengine?autoReconnect=true&useSSL=false&useUnicode=yes&characterEncoding=UTF-8";
				conn = DriverManager.getConnection(url, "root", "");	//get connection of database
			} catch (SQLException e) {
				e.printStackTrace();
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			}
		}
		
		//to execute the SQL query and the return the result set
		public ResultSet runSql(String sql) throws SQLException {
			Statement sta = conn.createStatement();
			return sta.executeQuery(sql);
		}
	 
		//override function finalize to close the connection with the database at the end
		@Override
		protected void finalize() throws Throwable {
			if (conn != null || !conn.isClosed()) {
				conn.close();
			}
		}
	
		//Indexer
		//SQL Insert in indexer
		public void insertIndexer(String Keyword,String Type,int ID,int count) throws SQLException
		{
			String query = " insert into indexer (UrlID,count,Keyword,Type)"  + " values (?,?,?,?)";
			try
			{
			PreparedStatement sqlStatement= conn.prepareStatement(query);
			sqlStatement.setInt (1, ID);
			sqlStatement.setInt (2, count);
			sqlStatement.setString (3, Keyword);
			sqlStatement.setString (4, Type);
			sqlStatement.execute();
			}
			catch(SQLException s)
			{
				return;
			}
		}
		
		//Insert Document of Pages Indexed
		public void insertDocument(Document webPage, int URLID) throws SQLException //Samar 30/4
		{
			String query = " Update visitedpages set Document = ? where ID = ?" ;
			try
			{
			PreparedStatement sqlStatement= conn.prepareStatement(query);
			String text = webPage.text();
			sqlStatement.setString (1, text);
			sqlStatement.setInt (2, URLID);
			sqlStatement.execute();
			}
			catch(SQLException s)
			{
				return;
			}
		}
		
		//delete the keywords resulted from the indexing of a page (in case this page will be re-crawled)
		public void deleteFromIndexer(int UrlID)
		{
			String query = " delete from indexer where UrlID = ?";
			try {
				PreparedStatement sqlStatement = conn.prepareStatement(query);
				sqlStatement.setInt (1, UrlID);
				sqlStatement.execute();
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return;
			
		}
		
		//To update the visited pages --> indexed
		public void isIndexed(int ID)
		{
			String query = " Update visitedpages set Indexed = 1 where ID = ?" ;
			PreparedStatement preparedStmt = null;
			try {
				preparedStmt = conn.prepareStatement(query);
				preparedStmt.setInt(1,ID);
				preparedStmt.executeUpdate();
			    
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		//to return the visited page to not indexed if the it will be recrawled after period of time (frequency)
		public void notIndexed(String Url)
		{
			String query = " Update visitedpages set Indexed = 0 where Url = ?" ;
			PreparedStatement preparedStmt = null;
			try {
				preparedStmt = conn.prepareStatement(query);
				preparedStmt.setString(1,Url);
				preparedStmt.executeUpdate();
			    
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		
		//Insert new keywords in indexer
		public void insertIndexer(String Keyword,String Type,int ID,int count,String position) throws SQLException
		{
			String query = " insert into indexer (UrlID,count,Keyword,Type,Position)"  + " values (?,?,?,?,?)";
			try
			{
				PreparedStatement sqlStatement= conn.prepareStatement(query);
				sqlStatement.setInt (1, ID);
				sqlStatement.setInt (2, count);
				sqlStatement.setString (3, Keyword);
				sqlStatement.setString (4, Type);
				sqlStatement.setString (5, position);
				sqlStatement.execute();
			}
			catch(SQLException s)
			{
				return;
			}
		}
		
		//gets
		//get the Url which the crawler will start with
		public String getStratingURL() 
		{
			String startingURL = "" ;
			String URL = "";
			String countURLS = "SELECT * FROM visitedpages";
			webCrawler crawler = new webCrawler();
			try {
				ResultSet emptyDBResult = this.runSql(countURLS);
				if(emptyDBResult.next())
				{

						try {
							FileReader toVisit = new FileReader("toVisit");
							try {
								int x = toVisit.read();
								while (x != -1)
								{
									URL += (char)x;
									x = toVisit.read();
								}
								toVisit.close();
								crawler.setToVisit(URL);
								startingURL = crawler.getFirstUrl();
							} catch (IOException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
						} catch (FileNotFoundException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
				}
				else
				{
					//startingURL = "https://www.techmeme.com/";
					crawler.setToVisit("https://en.wikipedia.org/wiki/Physics https://www.techmeme.com/ https://www.theguardian.com/media/magazines https://en.wikipedia.org/wiki/Main_Page https://www.rt.com/ https://www.nytimes.com/");
					startingURL = crawler.getFirstUrl();
				}
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			return startingURL;
		}
	
		//get next Url not indexed to pass it tp the indexer
		public String getIndexingURL()
		{
			String startingURL="" ;
			String notIndexedURLS = "SELECT * FROM visitedpages where Indexed=0";
			try {
				ResultSet DBResult = this.runSql(notIndexedURLS);
				if(DBResult.next())
				{
					startingURL=DBResult.getString(1);
				}
				
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			return startingURL;
		}
	
		//get the last date at which the page was visited
		public String getModifactionDate(String URL)
		{
			
			String Date = "" ;
			try {
				Statement stmt = conn.createStatement();
				ResultSet DBResult = stmt.executeQuery("Select ModificationDate from visitedpages where Url = '"+URL+"'");
				if(DBResult.next())
				{ 
					Date = DBResult.getString(1);
				}
				
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			return Date;
		}
		
		//get Url ID
		public int getUrlID(String URL)
		{
			int ID = 0;
			try {
				Statement stmt = conn.createStatement();
				ResultSet DBResult = stmt.executeQuery("Select ID from visitedpages where Url = '"+URL+"'");
				if(DBResult.next())
				{
					ID = DBResult.getInt(1);
				}
				
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			return ID;
			
		}

		//Crawler
		//set the new modification date in case the page is re-crawled
		public void updateDate(String Url)
		{
			String query = " Update visitedpages set ModificationDate = ? where Url = ?" ;
			PreparedStatement preparedStmt = null;
			try {
				preparedStmt = conn.prepareStatement(query);
				preparedStmt.setString(1,LocalDate.now().toString());
				preparedStmt.setString(2,Url);
				preparedStmt.executeUpdate();
			    
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		//Check if the Url was already visited by the crawler (his existence in the database)
		public boolean urlExistence(String URL)
		{
					
			try {
				Statement stmt = conn.createStatement();
				ResultSet DBResult = stmt.executeQuery("Select * from visitedpages where Url = '"+URL+"'");
				if(DBResult.next())
				{
					return true;
				}
						
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			return false;
		}
		
		//SQL Insert
		public boolean insertUrl(String Url, String Date) throws SQLException 
		{
			String query = " insert into visitedpages (Url,ModificationDate,Popularity)"  + " values (?,?,?)"; //may w salma
			try
			{
				PreparedStatement sqlStatement= this.conn.prepareStatement(query);
				sqlStatement.setString (1, Url);
				sqlStatement.setString(2, Date); 
				sqlStatement.setInt(3, 1); 
				sqlStatement.execute();
			}
			catch(SQLException s)
			{
				return false;
			}
			return true;
		}
		
		//Ranker
		//Update the Popularity of a Page (PageRank)
		public boolean updatePopularity(String Url) throws SQLException //may w salma
		{
			String query = " update visitedpages set Popularity=Popularity+1 where Url= ?" ;
			try
			{
				PreparedStatement sqlStatement= this.conn.prepareStatement(query);
				sqlStatement.setString (1, Url); 
				sqlStatement.executeUpdate();
			}
			catch(SQLException s)
			{
				return false;
			}
			return true;
		}
		
		//get count of documents containing the term (IDF)
		public int docContainsTermIDF(String word)  //salma 30/4
		{
			if(word.contains("'"))
			{
				word = word.replaceAll("'","''");	//if the Url contains ' then replace it for the SQL queries
			}
			
			String counter = "select count(distinct UrlID) FROM searchengine.indexer WHERE Keyword='"+word+"';";
			int	count=0; 
			try {
				Statement stmt = conn.createStatement();
				ResultSet DBResult = stmt.executeQuery(counter);
				//ResultSet DBResult = this.runSql(counter);
				if(DBResult.next())
				{
					count = DBResult.getInt(1);
				}
				
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			return count;
		}
		
		//get the count of the term in the document
		public int RepOfTerminDoc(String word, int UrlID)  //salma 30/4 complete
		{
			if(word.contains("'"))
			{
				word = word.replaceAll("'","''");	//if the Url contains ' then replace it for the SQL queries
			}
			
			ArrayList<Integer> wordCount = new ArrayList<Integer>();
			int count = 0;
			
			
			try {

				Statement stmt = conn.createStatement();
				String words = ("select count FROM indexer WHERE Keyword = '"+word+"' AND UrlID = '"+UrlID+"'");
				ResultSet DBResult = stmt.executeQuery(words);
				while(DBResult.next())
				{
					wordCount.add(DBResult.getInt(1));
					
					//counter = DBResult.getString(1);
				}
				for(int i=0; i<wordCount.size(); i++)
				{
					count = count + wordCount.get(i);
				}
				
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			return count;
		}
		
		public int docLength(int UrlID)  //salma 30/4 complete
		
		{
			ArrayList<Integer> wordCount = new ArrayList<Integer>();
			int count = 0;
			
			
			try {
				Statement stmt = conn.createStatement();
				String counter = ("select count FROM indexer WHERE UrlID = "+UrlID);
				ResultSet DBResult = stmt.executeQuery(counter);
				//ResultSet DBResult = this.runSql(counter);
				while(DBResult.next())
				{
					wordCount.add(DBResult.getInt(1));
					
					//counter = DBResult.getString(1);
				}
				for(int i=0; i<wordCount.size(); i++)
				{
					count = count + wordCount.get(i);
				}
				
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			return count;
		}
		
		public ArrayList<String> selectDistinctWords(int UrlID)  //Salma
		{
			ArrayList<String> distinctWords = new ArrayList<String>();
			
			
			
			try {
				//ResultSet DBResult = this.runSql(words);
				Statement stmt = conn.createStatement();
				String words = ("select distinct keyword from indexer WHERE UrlID = '"+UrlID+"'");
				ResultSet DBResult = stmt.executeQuery(words);
				while(DBResult.next())
				{
					distinctWords.add(DBResult.getString(1));
				}
					
				
				
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			return distinctWords;
		}
		
		
		public ArrayList<Integer> getAllUrlID()  //salma
		{
			ArrayList<Integer> UrlIds = new ArrayList<Integer>();
		//	String counter = ("select distinct UrlID FROM searchengine.indexer");
			
			try {
				Statement stmt = conn.createStatement();
				ResultSet DBResult = stmt.executeQuery("select distinct UrlID FROM searchengine.indexer");
				//ResultSet DBResult = this.runSql(counter);
				while(DBResult.next())
				{
					UrlIds.add(DBResult.getInt(1));
					
					//counter = DBResult.getString(1);
				}
				return UrlIds;
				
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
				return UrlIds;
			}
			
			
		}
		
		public void insertWordRank(double TDF_TF, int UrlID, String word)  //Salma
		{
			
			String query = " Update indexer set Rank = ? where UrlID = ? AND keyword = ?" ;
			try
			{
			PreparedStatement sqlStatement= conn.prepareStatement(query);
			sqlStatement.setDouble (1, TDF_TF);
			sqlStatement.setInt (2, UrlID);
			sqlStatement.setString (3, word);
			sqlStatement.executeUpdate();
			}
			catch(SQLException s)
			{
				return;
			}
		}
		
		
			
			
}