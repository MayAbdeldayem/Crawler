import java.io.IOException;
import java.sql.SQLException;


public class Main {

	public static void main(String[] args) throws IOException {
		String indexingURL="";
		Database DB = new Database();
		//String startingURL = "https://twitter.com/stevesi";
		String startingURL = DB.getStratingURL() ;					//get the first Url to start with
		webCrawler Spider = new webCrawler(startingURL,10, DB);
		Indexer indexer = null;
		
		int countThreads = 0;
		Spider.setName("Thread" + (1+countThreads));
		do{
			
			Spider.start();											//run the crawler threads
			try {
				Thread.currentThread();
				Thread.sleep(10000);
			} catch(InterruptedException e) {

			}
			
			//Indexing
			//Threads of web indexer
			indexer = new Indexer(DB,Spider);		
			indexer.setName("Ithread" + (1+countThreads) );			
			indexer.start();	
			
			startingURL = Spider.getNextUrlToVisit();
			Spider = new webCrawler(startingURL, DB);
			countThreads++;
			Spider.setName("Thread" + (1+countThreads));
			
		}while(startingURL != "" && countThreads < Spider.getmaxNumberOfThreads());


		try{	
			Spider.join();						//thread main wait until all threads of the crawler finish
			indexer.join();						//thread main wait until all threads of the indexer finish
			
			indexingURL = DB.getIndexingURL();	//if there is in the database pages that were not indexed (in case we have stopped the crawler and then start it again)
			do{
				if(indexingURL != "")
				{
					indexer = new Indexer(indexingURL,DB);
					try {
						indexer.indexing();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}			//go index those pages
					System.out.println("Thread main is indexing: " + indexingURL);
				}
				indexingURL = DB.getIndexingURL();
			} while(indexingURL !="");
			
		} catch (InterruptedException  e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}