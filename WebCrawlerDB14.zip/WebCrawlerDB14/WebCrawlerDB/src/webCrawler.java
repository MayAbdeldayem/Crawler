import java.io.FileWriter;
import java.io.IOException;
import java.net.ConnectException;
import java.net.HttpURLConnection;
import java.net.SocketException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Vector;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

import javax.net.ssl.SSLHandshakeException;

import org.jsoup.Connection;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.Period;
import java.math.*;



public class webCrawler extends Thread {
	private static HashSet<String> visitedPages = new HashSet<String>();						//HashSet for the visited pages
	private static BlockingQueue<String> pagesToVisit= new LinkedBlockingQueue<String>();		//Queue for the next to visit pages (blocking for the synchronization)
	private static List<String> newsUrls = new LinkedList<String>(Arrays.asList("http://www.infoworld.com/", "http://www.nydailynews.com/","http://www.autonews.com/","http://dailycaller.com/", "http://news.techmeme.com/" , "http://www.nytimes.com/", "https://www.rt.com/news/", "https://arabic.rt.com/"));  //News Urls to re-crawl them if the last visiting day was from one day
	private static final int maxNumberOfPages = 10000;											//Stopping criteria
	private String URL;
	private static int maxNumberOfThreads;														//Maximum number of threads indicated by the user
	private Database DB;
	private static Object obj = new Object();	
	private static LinkedList<Document> downloadedDocuments = new LinkedList<Document>();		//downloaded documents to be indexed
	private static LinkedList<String> tempVisitedPages = new LinkedList<String>();				//Urls of the downloaded documents
	
	
	//Constructors
	public webCrawler(String startingURL, Database DB) 
	{
		this.URL = startingURL;
		this.DB = DB;
	}
	public webCrawler(String startingURL , int maxNumberOfThreads, Database DB) 
	{
		this.URL = startingURL;
		webCrawler.maxNumberOfThreads = maxNumberOfThreads;
		this.DB = DB;
	}
	public webCrawler() 
	{
	}

	//Crawl
	public String crawl(String Url) throws IOException
	{
		String URLQuery;
		if(Url.contains("'"))
		{
			URLQuery = Url.replaceAll("'","''");	//if the Url contains ' then replace it for the SQL queries
		}
		else
			URLQuery = Url; //for queries
		
		boolean valid = true;	//boolean to indicate if the page is valid to crawl
		Document webPage = null;
		String nextUrl = "";
		
		if(URLQuery != null && Url != "")
		{
			String myCookie = "userId=igbrown";		//set the cookie
			Connection conn = Jsoup.connect(Url);		//connect on Jsoup
			conn.cookie("Cookie", myCookie);
			try {
				if( Url.startsWith("https://") || Url.startsWith("http://") )
					webPage = conn.get();				//get the webpage document
				else valid = false;
			} catch (IOException|IllegalArgumentException e) { //for the invalid cookie
					valid = false;
			}
		}
		else valid = false;
		
		if(DB.urlExistence(URLQuery))		//Check if the page was already visited 
		{
			if(!checkDate(URLQuery))		//Check the date of the last visit of the url to check if it has to be re-crawled (frequency)
				valid = false;
			else
				{
					DB.deleteFromIndexer(DB.getUrlID(URLQuery));	//if it will be re-crawled delete its keywords from the database
					DB.notIndexed(URLQuery); 						//Make it not indexed
					DB.updateDate(Url);								//set the new visiting date
				}
		}
		
		if(valid && !Url.contains("#") && !Url.contains("mailto")) //Samar 1/5
		{
			URL url = new URL(Url);
			HttpURLConnection connection = (HttpURLConnection)  url.openConnection();
			Vector<String> disallowedURLS = new Vector<String>();		//a vector to save the disallowed links from the robots.txt
			try{
				connection.setRequestMethod("HEAD");
				connection.connect();
			} catch (ConnectException|SSLHandshakeException e)
			{
				nextUrl = getNextUrlToVisit();
				return nextUrl;
			} catch (SocketException e)
			{
				nextUrl = getNextUrlToVisit();							//if the url is not valid to connect get the next Url
				return nextUrl;
			}
					
			String contentType = connection.getContentType();			//get the type of the Url to check if it is html or not
				
			if(contentType == null || contentType.contains("text/html"))
			{
				if( Url.startsWith("https") || Url.startsWith("http" ))
				{
					//robot 
					robotParser r = new robotParser();					//to check the robots.txt
					r.robot(url, disallowedURLS);
					if(!disallowedURLS.isEmpty()) 
					{
						if(!(disallowedURLS.size()==1 && disallowedURLS.get(0).equals("/")))	//disallow all 
						{
							Elements links = webPage.select("a[href]");							//select all urls in this page
							for(Element link:links)
							{
								boolean addLink = true;
								for(String disallowedLink: disallowedURLS)
								{
									if( link.toString().contains(disallowedLink))				//if the link contains a disallowed part
									{
										addLink = false;
										break;
									}		
								}
								if(addLink  && link.absUrl("href") != "")
									pagesToVisit.add(link.absUrl("href"));						//add links to next to visit
							}
							
						
							FileWriter toVisitFile = new FileWriter("toVisit",false);			//a file to save some next to visit to begin with if the crawler has stopped
							for(int i = 0 ; i < maxNumberOfThreads ; i++)
							{
								String savedUrl = null;
								if(!pagesToVisit.peek().equals("https://www.rt.com/") && !pagesToVisit.peek().equals("https://www.techmeme.com/") && !pagesToVisit.peek().equals("https://www.wikipedia.org/"))
										savedUrl = pagesToVisit.poll();
								if(savedUrl != null) 
								{
									toVisitFile.write(savedUrl +" "); 
									pagesToVisit.add(savedUrl);
								}
							}
						
							toVisitFile.close();
							
							synchronized(obj)	
							{
								if(!visitedPages.contains(Url) && visitedPages.size() < maxNumberOfPages)		//check if the url was visited before and if the size reached the maximum
								{
									boolean inserted = false;
									try {
										inserted = DB.insertUrl(URLQuery,LocalDate.now().toString());  			//insert in the database
									} catch (SQLException e) {
										e.printStackTrace();
									}
									if(inserted)
									{
										visitedPages.add(Url);													//insert in the visited pages list
										System.out.println(Thread.currentThread().getName() + " : " + Url + " " + visitedPages.size());
									}
									tempVisitedPages.add(Url);													//list of visited urls to send to the indexer
									downloadedDocuments.add(webPage);											//list of downloaded documents to send to the indexer
									obj.notifyAll();															//to notify to the indexer threads that new page has been added
									
								}
							}
						}	
					}
					else	//if all the urls are allowed
					{
						Elements links = webPage.select("a[href]");
						for(Element link:links)
						{
							pagesToVisit.add(link.absUrl("href"));
						}
		
						synchronized(obj)	
						{
							//The crawler must not visit the same URL more than once
							if(!visitedPages.contains(Url) && visitedPages.size() < maxNumberOfPages)
							{
								boolean inserted = false;
								try {
									inserted = DB.insertUrl(URLQuery,LocalDate.now().toString());  
								} catch (SQLException e) 
								{
									e.printStackTrace();
								}
							
								if(inserted)
								{
									visitedPages.add(Url);
									System.out.println(Thread.currentThread().getName() + " : " + Url + " " + visitedPages.size());

								}
								tempVisitedPages.add(Url);
								downloadedDocuments.add(webPage);
								obj.notifyAll();
							}
							else
							{
								try {
									DB.updatePopularity(Url);
								} catch (SQLException e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								}
							}
						}	
					}
				}
			}
		}
		nextUrl = getNextUrlToVisit();		
		return nextUrl;					//return the next Url to crawl
	}
	
	//Overriding run method in thread
	public void run() 
	{	
		String startingUrl = URL;
		do{
			//Samar 1/5
			URI uri = null;
			try {
				uri = new URI(startingUrl);
			} catch (URISyntaxException e1) {
				// TODO Auto-generated catch block
				return;
			}
			if(uri != null)
			{
				uri = uri.normalize();
				startingUrl = uri.toString();
			}
			
			try {
				System.out.println(Thread.currentThread().getName() + " : URLTOVISIT " + startingUrl);			
				startingUrl = crawl(startingUrl);				//start crawling
				if(startingUrl == "")
				{
					if(!pagesToVisit.isEmpty())
						startingUrl = pagesToVisit.poll();		//get the next page to crawl
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
			
		}while(startingUrl != "" && startingUrl != null && visitedPages.size() < maxNumberOfPages);	
	}
	
	//get Maximum number of pages
	public int getmaxNumberOfPages()
	{
		return maxNumberOfPages;
	}
	//Returning size of visited pages
	public int getSizeOfVisitedPages()
	{
		return visitedPages.size();
	}
	//get Maximum number of threads
	public int getmaxNumberOfThreads()
	{
		return maxNumberOfThreads;
	}
	//get next URL from the linked list pages to visit
	public synchronized String getNextUrlToVisit()
	{
		String nextUrl = "";
		do{
			if(pagesToVisit.isEmpty())
				break;
			
			nextUrl = pagesToVisit.poll();
			if(nextUrl == null)
				break;
		}while(nextUrl == "" || visitedPages.contains(nextUrl));
		
		return nextUrl;	
	}		
	
	//get downloadedDocuments 								
	public LinkedList<Document> getDownloadedDocuments()	
	{
		return downloadedDocuments;							
	}
	public LinkedList<String> getTempVisitedPages() 
	{
		return tempVisitedPages;
	}
	//set the temp visited pages after taking a url from it in the indexer to index it
	public void setTempVisitedPages(LinkedList<String> tempVisitedPages)
	{
		webCrawler.tempVisitedPages = tempVisitedPages;
	}
	//get firt url to visit
	public String getFirstUrl()
	{
		return pagesToVisit.poll();
		
	}
	//set next urls to visit from the file
	public void setToVisit(String urls)
	{
		String [] url = urls.split(" ");
		
		for(int i = 0 ; i < url.length ; i++)
		{
			pagesToVisit.add(url[i]);		
		}

	}
	
	//check the date of the last visit of the page to know if it will be re-crawled
	public boolean checkDate(String Url)
	{
		String urlDate = DB.getModifactionDate(Url);
		int urlYear = Integer.parseInt(urlDate.substring(0,4));
		int urlMonth = Integer.parseInt(urlDate.substring(5,7));
		int urlDay = Integer.parseInt(urlDate.substring(8,10));
		
		LocalDate dateUrl = LocalDate.of(urlYear, urlMonth, urlDay);
		LocalDate dateCurrent = LocalDate.now();
		Period period = Period.between(dateUrl , dateCurrent);
		if(newsUrls.contains(Url)) 
		{
			if(period.getDays() >= 1)
				return true;
			return false;
		}
		else if(period.getDays() >= 3)
			return true;
		return false;
				
	}
	

	
}

