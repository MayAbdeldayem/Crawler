import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Map.Entry;
import java.util.Set;
import org.jsoup.Connection;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.tartarus.snowball.ext.englishStemmer;

public class Indexer extends Thread {
	private String indexingURL = "";																	//first Url to index
	private Database DB;
	private static webCrawler wCrawler;		
	private static int numberOfIndexedPages = 0;														//number of indexed pages	
	private static Object obj = new Object();			
	private HashMap<String, HashMap<HashMap<String,String>, Integer>> keywordsAndTypesCount = new HashMap<String, HashMap<HashMap<String,String>, Integer>>(); //HashMap for the keyword, its positions, type and count in a page
	private static String unecessaryChar = "��:;,.-_^~�()[]'?|><!�{}*&+�$@%`�--=/" + "\""+'"';			//Array of unnecessary characters
	
	//constructors
	public Indexer(String indexingURL,Database DB)
	{
		this.indexingURL = indexingURL;
		this.DB = DB;
		
	}
	public Indexer(Database DB, webCrawler wCrawler)
	{
		this.DB = DB;													
		Indexer.wCrawler = wCrawler;									
	}
	
	//indexing undownloaded pages
	public void indexing() throws SQLException
	{
		boolean valid = true;
		Document webPage = null;
		Connection conn = Jsoup.connect(indexingURL);	
		try {
			webPage = conn.get();													//download the pages
		} catch (IOException e) {
				valid = false;
		}
		if(valid)
		{	
			String URL;
			if(indexingURL.contains("'"))
			{
				URL = indexingURL.replaceAll("'","''");								//replace ' with  '' for the query
			}
			else
				URL = indexingURL;
			 int URLID = 0;
			 String sql = "Select ID From visitedpages where Url = '"+ URL +"'";	//get the ID of the URL
			 try {
				ResultSet Result = DB.runSql(sql);
				Result.next();
				URLID = Result.getInt(1);
			 	} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			 }
			 
			 //get keywords with certain type from the webpage
			 insertTypeAndWord("p", webPage);
			 insertTypeAndWord("h1", webPage);
			 insertTypeAndWord("h2", webPage);
			 insertTypeAndWord("h3", webPage);
			 insertTypeAndWord("h4", webPage);
			 insertTypeAndWord("h5", webPage);
			 insertTypeAndWord("h6", webPage);
			 insertTypeAndWord("title", webPage);
			 
			 
			 String [] KeyWordsArr = new String [keywordsAndTypesCount.size()];
				keywordsAndTypesCount.keySet().toArray(KeyWordsArr);
				for(int i = 0 ; i < KeyWordsArr.length ; i++)
				{
					HashMap<HashMap<String,String>,Integer>typesCountPosition = keywordsAndTypesCount.get(KeyWordsArr[i]);		//get the value HashMap containing type, count and position
					Set<Entry<HashMap<String, String>, Integer>> typesPositionSet = typesCountPosition.entrySet();				//get the set for the for loop
					for (Entry<HashMap<String, String>,Integer> entry : typesPositionSet) 
					{
						String type =	entry.getKey().keySet().toString();														//get the type of the keyword
						String position = entry.getKey().values().toString();													//get the position of the keyword
						int count = entry.getValue();																			//get the value of the small HashMap count
						try 
						{
							DB.insertIndexer(KeyWordsArr[i],type,URLID,count,position);											//insert in the database the keyword with the type, count, position and URLID	
						} catch (SQLException e) 
						{
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
				
					}
				}
					
				DB.isIndexed(URLID);																						//set the Url indexed
				DB.insertDocument(webPage, URLID);
				keywordsAndTypesCount.clear();																				//Clear the HashMap 
		}
			 
	}
	
	public void indexingDownloadedDocuments() throws SQLException
	{
		LinkedList<Document> downloadedDocuments = wCrawler.getDownloadedDocuments();
		LinkedList<String> tempVisitedPages = wCrawler.getTempVisitedPages();
		if(!downloadedDocuments.isEmpty())
		{
			Document webPage = null;
			synchronized (obj)				
			{
				webPage = downloadedDocuments.removeFirst();				//remove from the downloaded documents to index the pages
				indexingURL = tempVisitedPages.removeFirst();
			}							
			
			System.out.println(Thread.currentThread().getName() +" : INDEXER URL TOBE INDEXED : " + indexingURL);
			
			if(webPage != null)
			{
				String URL;
				if(indexingURL.contains("'"))
				{
					URL = indexingURL.replaceAll("'","''");					//replace ' with  '' for the query
				}
				else
					URL = indexingURL;
				
				 //get keywords with certain type from the webpage
				int URLID = DB.getUrlID(URL);
				insertTypeAndWord("p", webPage);
				insertTypeAndWord("h1", webPage);
				insertTypeAndWord("h2", webPage);
				insertTypeAndWord("h3", webPage);
				insertTypeAndWord("h4", webPage);
				insertTypeAndWord("h5", webPage);
				insertTypeAndWord("h6", webPage);
				insertTypeAndWord("title", webPage);
				
				String [] KeyWordsArr = new String [keywordsAndTypesCount.size()]; 
				keywordsAndTypesCount.keySet().toArray(KeyWordsArr);
				for(int i = 0 ; i < KeyWordsArr.length ; i++)
				{
					HashMap<HashMap<String,String>,Integer>typesCountPosition = keywordsAndTypesCount.get(KeyWordsArr[i]);		//get the value HashMap containing type, count and position
					Set<Entry<HashMap<String, String>, Integer>> typesPositionSet = typesCountPosition.entrySet();				//get the set for the for loop
					for (Entry<HashMap<String, String>,Integer> entry : typesPositionSet) 
					{
						String type =	entry.getKey().keySet().toString();														//get the type of the keyword
						String position = entry.getKey().values().toString();													//get the position of the keyword
						int count = entry.getValue();																			//get the count of the keyword
						try 
						{
							DB.insertIndexer(KeyWordsArr[i],type,URLID,count,position);											//insert in the database
						} catch (SQLException e) 
						{
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
				
					}
				}
					
				DB.isIndexed(URLID);																							//Set the url to indexed
				DB.insertDocument(webPage, URLID);
				wCrawler.setTempVisitedPages(tempVisitedPages);																	//set the temp visited pages after removing from it to index the urls
				Indexer.numberOfIndexedPages++;																					//increment the number of indexed urls
				keywordsAndTypesCount.clear();
				System.out.println(Thread.currentThread().getName() +" : INDEXER URL : " + indexingURL);	
				
			}
		}
		else											
		{
			try {								
					if(wCrawler.getSizeOfVisitedPages() < wCrawler.getmaxNumberOfPages())
						obj.wait();																								//if there is no page to index wait until the crawler visit another page
				} catch (InterruptedException e) 	
				{
					e.printStackTrace();		
				}
		}
	}
	
	
	public void run()
	{
		while(!wCrawler.getDownloadedDocuments().isEmpty() && numberOfIndexedPages < wCrawler.getmaxNumberOfPages())
		{
			try {
				indexingDownloadedDocuments();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}				//start indexing of downloaded pages
		}
	}
			 
	

 public void insertTypeAndWord(String type, Document webPage) 
	{
		Elements elementsArrayType; 
		elementsArrayType = webPage.getElementsByTag(type); 
		int newLine = 0;  			//if there is a new paragraph or header or  title
		int lastIndex = 0;	 		//to record the index of the last word in the first paragraph for example 
		for(Element element: elementsArrayType)
		{
			if(element != null && element.hasText())
			{
				newLine = newLine + lastIndex;
				String [] wordsArray = null;  
				String [] enterSplit = element.text().split("\r\n");
				
				for(int i = 0 ; i < enterSplit.length ; i++)
				{
					//replace unwanted characters in the string
					enterSplit[i] = enterSplit[i].replace("\u00a0"," "); 			//&nbps
					enterSplit[i] = enterSplit[i].replace("@", " ");
					enterSplit[i] = enterSplit[i].replace("#", " ");
					enterSplit[i] = enterSplit[i].replace('"', ' ');
					enterSplit[i] = enterSplit[i].replace(",", " ");
					enterSplit[i] = enterSplit[i].replace(";", " ");
					enterSplit[i] = enterSplit[i].replace("!", " ");
					enterSplit[i] = enterSplit[i].replace("?", " ");
					enterSplit[i] = enterSplit[i].replace(".", " ");
					enterSplit[i] = enterSplit[i].replace("(", " ");
					enterSplit[i] = enterSplit[i].replace(")", " ");
					enterSplit[i] = enterSplit[i].replace(":", " ");
					//enterSplit[i] = enterSplit[i].replaceAll("\\d", " ");
					wordsArray = enterSplit[i].split(" ");  						//Split on the spaces to get the words
				}
			
				for(int i = 0 ; i < wordsArray.length ; i++)  
				{
					Set<Entry<String, HashMap<HashMap<String, String>, Integer>>> typesPositionSet = keywordsAndTypesCount.entrySet(); //Set of keywords, position, type and count
					HashMap<String,String> typePosition = new HashMap<String,String>();
					if(wordsArray[i] != "" && wordsArray[i] != "\r\n")																	//check if the word is not empty or enter
					{
						if(!wordsArray[i].contains(" "))																				//check if the word is not a space
						{
							if(!unecessaryChar.contains(wordsArray[i]) && !wordsArray[i].contains("http") && !wordsArray[i].contains("https"))	//remove the unwanted characters and the urls
							{
								englishStemmer english= new englishStemmer();
								english.setCurrent(wordsArray[i]);
								if(english.stem())
									wordsArray[i] = english.getCurrent();
							
								if(keywordsAndTypesCount.containsKey(wordsArray[i]))															//check if the hashmap already has the keyword to get it and increment the count and add to the position	
								{	
										for (Entry<String, HashMap<HashMap<String, String>, Integer>> entry : typesPositionSet) 
										{
											if(entry.getKey().equals(wordsArray[i]))
											{
												Set<Entry<HashMap<String,String>,Integer>> typesPositionSet2 = entry.getValue().entrySet();
												if(!typesPositionSet2.isEmpty())
													{
															Iterator<Entry<HashMap<String, String>, Integer>> iterate = typesPositionSet2.iterator();
															Entry<HashMap<String,String>,Integer> entry2 = (Entry<HashMap<String, String>, Integer>) iterate.next();		//Iterate over the hashmap of position, count and type
															if(entry2.getKey().containsKey(type))
															{	
																String oldPosition = entry2.getKey().get(type) ; 															//get the old position of the keyword
																int index = i + newLine;
																String newPosition = oldPosition +","+ index; 																//add the new position
																int count = entry2.getValue();  
																typePosition.put(type, newPosition);
																iterate.remove();																							//remove the keyword to insert it again with the new positions 
																keywordsAndTypesCount.get(wordsArray[i]).put(typePosition,++count);
															}
															else
															{
																int index = i + newLine;
																String position = String.valueOf(index);
																typePosition.put(type, position);
																keywordsAndTypesCount.get(wordsArray[i]).put(typePosition,1);
															}
													}
											}
										}
									}
								else
								{

								    HashMap<HashMap<String,String>,Integer> typesCountPosition = new  HashMap<HashMap<String,String>,Integer>();		
								    typePosition.put(type, String.valueOf(i + newLine));
								    typesCountPosition.put(typePosition,1);							//prepare the small HashMap with type, position and count = 1
									keywordsAndTypesCount.put(wordsArray[i],typesCountPosition);	//if the keyword was not in the HashMap, add it for the first time with count = 1 
									
								}
							}
						}
					}
					lastIndex = i + 1;
				}
			}
		}
	}
}