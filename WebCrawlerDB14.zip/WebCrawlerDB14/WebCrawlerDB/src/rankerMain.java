import java.util.ArrayList;

public class rankerMain {
	
	private static Database DB= new Database();

	public static void main(String[] args) {
		
		ArrayList<Integer> allUrls = new ArrayList<Integer>();
		 allUrls =DB.getAllUrlID();
		
		for(int i=0; i< allUrls.size(); i++)
		{
			ArrayList<String> distinctWords = DB.selectDistinctWords(i);
			for(int j=0; j<distinctWords.size(); j++ )
			{
				double result = TDF_TF(distinctWords.get(j), i, DB.getAllUrlID().size());
				DB.insertWordRank(result, i, distinctWords.get(j));
			}
			
		}
		
		
		

	}
	
	public static double TDF_TF(String word, int UrlID, int maxNumOfPages)  //Salma
	{
		double totalNumOfDoc = maxNumOfPages;
		//int UrlID = DB.getUrlID(Url);
		double docsContainingWord = DB.docContainsTermIDF(word);
		double IDF = Math.log(totalNumOfDoc/docsContainingWord);
		float wordRepInDoc = DB.RepOfTerminDoc(word, UrlID);
		float docLength = DB.docLength(UrlID);
		float TF = wordRepInDoc/docLength;
		return (IDF*TF);
	}

}
